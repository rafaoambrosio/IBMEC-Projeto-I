from flask import Flask, render_template, request, redirect, url_for
from tinyDB_tutorial import DAO

app = Flask(__name__)

@app.route('/app-school')
@app.route('/app-school/')
@app.route('/app-school/index')
@app.route('/app-school/index.html')
def index():
    return render_template('index.html')

@app.route('/app-school/curso/listar')
def listar_curso():
    return render_template('/curso/listar.html', cursos=DAO().listar())

@app.route('/app-school/curso/novo')
def novo_curso():
    return render_template('/curso/inserir.html')

@app.route('/app-school/curso/inserir', methods=['POST'])
def inserir_curso():
    nome = request.form.get('nome')
    descricao = request.form['descricao']
    print(nome, descricao)
    return redirect(url_for('listar'))

@app.route('/app-school/curso/cadastrar')
def cadastrar_curso():
    return render_template('/curso/form.html')

@app.route('/app-school/estudante/listar')
def listar_estudante():
    return render_template('/estudante/listar.html', estudantes=DAO().listar())

@app.route('/app-school/estudante/novo')
def novo_estudante():
    return render_template('/estudante/inserir.html')

@app.route('/app-school/estudante/inserir', methods=['POST'])
def inserir_estudante():
    nome = request.form.get('nome')
    email = request.form['email']
    idade = request.form['idade']
    print(nome, email, idade)
    return redirect(url_for('listar'))

@app.route('/app-school/estudante/cadastrar')
def cadastrar_estudante():
    return render_template('/estudante/form.html')